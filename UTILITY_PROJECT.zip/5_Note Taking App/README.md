<h1>Note Taking App</h1>
<br>
This is a Note Taking App built with HTML, CSS, JS by Ankan Maity.
